require 'highrise'

Highrise::Base.site = 'https://kasemchalliou.highrisehq.com'
Highrise::Base.user = 'bf7082866adcd4279b15adcb57ec2898'
Highrise::Base.format = :xml