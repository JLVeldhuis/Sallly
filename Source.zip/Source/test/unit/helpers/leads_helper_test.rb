require 'test_helper'

class LeadsHelperTest < ActionView::TestCase
end
