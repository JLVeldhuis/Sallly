require 'test_helper'

class SettingHelperTest < ActionView::TestCase
end
