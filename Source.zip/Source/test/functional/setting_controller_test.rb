require 'test_helper'

class SettingControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
