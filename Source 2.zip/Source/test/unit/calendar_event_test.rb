require 'test_helper'

class CalendarEventTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
