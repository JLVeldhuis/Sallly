require 'test_helper'

class CalendarEventsHelperTest < ActionView::TestCase
end
