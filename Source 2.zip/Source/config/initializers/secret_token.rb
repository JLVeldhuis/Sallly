# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Forevenue::Application.config.secret_token = 'd899ec7c88b1a59c995fe35b987230d8a83bee3b87a84a033c0ed7fca8fa12a1291e21031a575b0cfe96126b3d8d263c623516e5e1319c84923e927c4f9951ef'
