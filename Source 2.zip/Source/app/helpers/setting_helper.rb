module SettingHelper
end
